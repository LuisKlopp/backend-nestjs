export class PostDto {
  readonly id: number;
  readonly views: number;
  readonly likes: number;
}
